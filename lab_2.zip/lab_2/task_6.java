
import java.util.Scanner;
class task_6{
public static void main(String []args){
Scanner input =new Scanner(System.in);
System.out.println("Enter your Age :");
int age =input.nextInt();
String result=(age>18)? "You are eligible for voting . " : " Sorry , You are not eligible for voting .";

System.out.println(result);

}

}