class task_7{
public static void main(String args []){
int [] arr = {20,2,44,35,57,7,98,26,77,33};
int max = arr[0];
int min = arr[0];
System.out.println("Array values:");
for(int i=0;i<arr.length;i++)
{
System.out.println(arr[i]);

if(arr[i]>max)
{
max=arr[i];
}

if(arr[i]<min)
{
min=arr[i];
}
}
System.out.println("Maximum number :" + max);
System.out.println("Minnimum number : " + min);

if(max%2==0)
{
System.out.println("The Maximum number is divisible by 2.");
}
else
{
System.out.println("The Maximum number is not divisible by 2.");
}

}
}
